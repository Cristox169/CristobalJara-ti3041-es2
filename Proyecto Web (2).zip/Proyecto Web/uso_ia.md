# Registro de uso de inteligencia artificial

## Parte 1 Registro de consultas

### Consulta 1 Creación inicial del proyecto

**Prompt textual:** Crea un entorno virtual instalando todo lo necesario para correr Django. La carpeta del proyecto debe ser limpia, con una carpeta para cada lenguaje. Elabora el proyecto en Django según la guía facilitada, agrega un nav dinámico con todos los accesos y configuraciones disponibles y un footer. Todo debe realizarse en Visual Studio Code.

**Resumen de la respuesta:** Se propuso una aplicación Django con catálogo de productos, navegación dinámica, panel administrativo, API JSON, plantillas y estilos separados.

**Qué se usó o modificó:** Se mantuvo la estructura del proyecto, pero luego se adaptó a la pauta ES2 agregando `.venv`, `requirements.txt`, administración, migraciones y un poblamiento reproducible.

### Consulta 2 Ajuste a la guía de Programación Back End

**Prompt textual:** Según la guía facilitada existen diferencias. Ejecutarlo tal cual está detallado en la guía.

**Resumen de la respuesta:** Se reorganizaron `manage.py`, `config` y `productos` en la raíz, se configuró el entorno y se validaron las migraciones y pruebas.

**Qué se usó o modificó:** Se conservó la aplicación funcional y posteriormente se reincorporó `requirements.txt` porque la pauta ES2 lo exige explícitamente.

### Consulta 3 Base de datos integral para ferretería

**Prompt textual:** Es necesario crear una base de datos totalmente normalizada en quinta forma normal para la administración de una ferretería, dando abasto para ventas, recursos humanos, logística, producción, análisis de costos e ingresos. Actualizar completamente las consultas y estructura del sitio web Django para responder únicamente desde la base de datos, con un sitio estilizado y humanizado. No subir nada a GitHub hasta revisar y asegurar el funcionamiento.

**Resumen de la respuesta:** Se diseñó una estructura relacional separando datos maestros, relaciones muchos a muchos, documentos con cabecera y detalle, históricos de precio y contrato, movimientos de inventario, producción y clasificación financiera. También se actualizaron vistas, consultas, administración, pruebas y diseño.

**Qué se usó o modificó:** El esquema se adaptó al contexto chileno, se conservaron datos existentes mediante migraciones progresivas y se añadió un comando ORM idempotente para poblar todas las áreas.

### Consulta especial Poblamiento inicial obligatorio

**Prompt textual:** Genera datos realistas en español para una ferretería chilena con al menos 40 productos. Cada producto debe tener SKU, nombre, categoría, marca, unidad, descripción, precio de venta, costo, stock y punto de reposición. Además, crea datos relacionados para proveedores, bodegas, clientes, ventas, compras, empleados, contratos, turnos, producción y transacciones financieras, listos para cargar mediante el ORM de Django sin duplicar registros.

**Resumen de la salida:** Se generaron 40 productos distribuidos en herramientas manuales, herramientas eléctricas, fijaciones, pinturas, electricidad, gasfitería, seguridad industrial, construcción y organización de taller. También se generaron entidades y movimientos de demostración para todas las áreas.

**Ajustes antes de cargar:** La salida se implementó como el comando `python manage.py poblar_ferreteria`. Se usó `update_or_create`, claves únicas y tablas puente para que sea idempotente. Los precios se cargan en `PrecioProducto` y el stock en `MovimientoInventario`, en lugar de duplicarlos en `Producto`.

## Parte 2 Explicación personal del proceso

Esta sección debe ser escrita por el estudiante con sus propias palabras, entre 10 y 20 líneas, antes de la entrega. La pauta prohíbe expresamente que la IA redacte o resuma esta parte.

Este desafio lo he tomado entre mis manos con especial afecto, ya que es una valiosa instancia para poner a prueba mis habilidades de aprendizaje y mi capacidad para sortear obstaculos. En el siguiente relato planteare una serie de preguntas que con honestidad marcan el camino seguido para el desarrollo de este bello proyecto de aprendizaje. 

1. ¿Qué necesitabas construir y por qué pediste apoyo a la IA?
Necesitaba construir una pagina para una ferreteria y le pedi ayuda a la IA porque no sabia como empezar el proyecto
2. ¿Qué parte de la estructura propuesta comprendiste y utilizaste?
Ninguna
3. ¿Qué respuesta tuviste que corregir o adaptar?
4. ¿Cómo comprobaste que los datos provenían de la base de datos?
AL eliminar un producto y ver que desaparece del listado
5. ¿Qué aprendiste sobre modelos, migraciones, Admin y ORM?
Nada nuevo
6. ¿Qué fragmento del código podrías explicar durante la revisión?
Ninguno

