# Ferretería Central — sistema Django normalizado

Sistema académico de gestión integral para una ferretería. El sitio obtiene los datos comerciales exclusivamente desde SQLite mediante el ORM de Django y cubre catálogo, ventas, inventario y compras, recursos humanos, producción, logística y análisis financiero.

## Requisitos cubiertos

- Catálogo con más de 40 productos realistas en español, categorías normalizadas, precio vigente e inventario derivado.
- Modelo relacional descompuesto hasta quinta forma normal (5FN), con documentación de dependencias y tablas puente.
- CRUD de productos, buscador, filtros, API JSON y panel administrativo con búsqueda, filtros y listados.
- Módulos operacionales para ventas, logística, personas, producción y finanzas.
- Navegación dinámica cargada desde `json/site.json`, footer global y diseño responsive.
- Poblamiento reproducible mediante un comando ORM idempotente.
- Bitácora de apoyo con IA y espacio reservado para la reflexión personal exigida por la evaluación.

## Instalación en Windows y Visual Studio Code

El proyecto ya incluye `.venv`, `Pipfile`, `Pipfile.lock`, `requirements.txt` y configuración de VS Code. Para reconstruir el entorno desde cero:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python manage.py migrate
python manage.py poblar_ferreteria
python manage.py createsuperuser
python manage.py runserver
```

También se puede conservar el flujo de la guía con Pipenv:

```powershell
python -m pip install pipenv
python -m pipenv install
python -m pipenv run python manage.py migrate
python -m pipenv run python manage.py poblar_ferreteria
python -m pipenv run python manage.py runserver
```

Abrir <http://127.0.0.1:8000/>. En VS Code se puede iniciar desde **Ejecutar y depurar** con la configuración **Django: ejecutar servidor**.

## Estructura por responsabilidad

```text
Proyecto Web/
├── .venv/                         # entorno virtual local
├── .vscode/                       # intérprete y depuración de VS Code
├── config/                        # configuración central de Django
├── connectBD/
│   └── consultas.sql              # único archivo de consultas SQL manuales
├── css/
│   └── styles.css                 # estilos globales responsive
├── docs/
│   └── normalizacion_5fn.md       # justificación de la normalización
├── html/                          # plantillas Django
├── json/
│   └── site.json                  # navegación y contenido global
├── productos/                     # modelos, vistas, formularios, admin y pruebas
│   ├── management/commands/
│   │   └── poblar_ferreteria.py   # carga de datos vía ORM
│   └── migrations/                # evolución reproducible del esquema
├── db.sqlite3                     # base local (se genera con migrate)
├── manage.py
├── requirements.txt
├── Pipfile
├── Pipfile.lock
└── uso_ia.md
```

## Diseño de datos

`Producto` conserva únicamente atributos propios. El precio se versiona en `PrecioProducto`; el stock se calcula sumando `MovimientoInventario`; las relaciones multivaluadas se separan en tablas como `ProductoProveedor`, `DespachoVenta`, `ComponenteReceta` y `AsignacionTurno`. Los documentos transaccionales usan cabecera y detalle. La justificación completa está en [`docs/normalizacion_5fn.md`](docs/normalizacion_5fn.md).

SQLite es la base configurada para esta entrega. Las consultas SQL equivalentes están centralizadas en [`connectBD/consultas.sql`](connectBD/consultas.sql); la aplicación no depende de SQL incrustado en vistas o plantillas.

## Rutas

- `/` — tablero general con indicadores calculados desde la base.
- `/productos/` — catálogo, búsqueda, categorías y ordenamiento.
- `/productos/nuevo/` — alta de producto, precio y movimiento inicial.
- `/ventas/` — ingresos, costos, margen y últimas ventas.
- `/logistica/` — inventario por bodega, compras y movimientos.
- `/recursos-humanos/` — empleados, contratos y costo de nómina vigente.
- `/produccion/` — órdenes, recetas, consumos y avance.
- `/finanzas/` — ingresos, costos, gastos y resultado.
- `/api/productos/` — API JSON calculada desde el modelo normalizado.
- `/configuracion/` — entorno y accesos disponibles.
- `/admin/` — administración completa de Django.

## Verificación

```powershell
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py test productos
python manage.py poblar_ferreteria
```

El comando de poblamiento puede ejecutarse más de una vez sin duplicar las entidades identificadas. Antes de entregar, se debe completar personalmente la Parte 2 de `uso_ia.md`, ya que la pauta prohíbe que esa reflexión sea redactada por IA.

No se realizó ningún commit ni subida a GitHub; el proyecto queda local para revisión funcional.
