# Productly — proyecto Django

Aplicación académica basada en la guía **Programación Back-end** de Notion. Incluye catálogo CRUD de productos, buscador, filtros, panel administrativo, navegación dinámica, API JSON y diseño responsive.

## Secuencia aplicada desde la guía

Estos son los comandos de la guía para recrear la base del proyecto desde una carpeta vacía:

```powershell
mkdir mi_proyecto_web
cd mi_proyecto_web
pip install pipenv
python -m pipenv install django
python -m pipenv shell
python -m django startproject config .
python manage.py runserver
python manage.py startapp productos
```

Después se registra `productos.apps.ProductosConfig` en `INSTALLED_APPS`, se crea `productos/urls.py`, se definen los modelos y se ejecutan las migraciones. Este repositorio ya contiene todos esos pasos terminados.

## Puesta en marcha

El entorno virtual fue creado con **Pipenv** siguiendo la guía y se guarda en `.venv`. Visual Studio Code está configurado para seleccionarlo automáticamente.

```powershell
python -m pipenv shell
python manage.py migrate
python manage.py runserver
```

Abrir <http://127.0.0.1:8000/>. Para crear acceso al panel administrativo:

```powershell
python manage.py createsuperuser
```

También se puede iniciar desde **Ejecutar y depurar** en VS Code con la configuración `Django: ejecutar servidor`.

## Estructura limpia por tecnología

```text
Proyecto Web/
├── .venv/                  # entorno virtual de Pipenv
├── .vscode/                # intérprete y depuración de VS Code
├── config/                 # proyecto central creado con startproject
├── connectBD/
│   └── consultas.sql       # todas las consultas SQL manuales
├── css/
│   └── styles.css          # estilos globales responsive
├── html/                   # todas las plantillas Django
├── json/
│   └── site.json           # navegación y datos globales del sitio
├── productos/              # aplicación creada con startapp
├── manage.py               # comando principal de Django
├── Pipfile                 # dependencias administradas por Pipenv
├── Pipfile.lock            # versiones exactas instaladas
└── README.md
```

## Rutas principales

- `/` — inicio y resumen del inventario.
- `/productos/` — catálogo con búsqueda, categorías y ordenamiento.
- `/productos/nuevo/` — alta de producto.
- `/api/productos/` — listado JSON.
- `/configuracion/` — resumen del entorno y mapa de accesos.
- `/admin/` — panel administrativo de Django.

## Comandos de calidad

```powershell
python manage.py check
python manage.py test productos
```

La base SQLite `db.sqlite3` se crea en la raíz después de ejecutar las migraciones y se puede inspeccionar con DB Browser for SQLite.
