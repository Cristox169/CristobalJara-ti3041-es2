from django import forms

from .models import Producto


class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = [
            "nombre",
            "sku",
            "descripcion",
            "categoria",
            "precio",
            "stock",
            "imagen_url",
            "activo",
        ]
        widgets = {
            "nombre": forms.TextInput(attrs={"placeholder": "Ej. Teclado mecánico"}),
            "sku": forms.TextInput(attrs={"placeholder": "Ej. TEC-001"}),
            "descripcion": forms.Textarea(
                attrs={"rows": 4, "placeholder": "Características principales"}
            ),
            "precio": forms.NumberInput(attrs={"min": 0, "step": "0.01"}),
            "stock": forms.NumberInput(attrs={"min": 0}),
            "imagen_url": forms.URLInput(
                attrs={"placeholder": "https://ejemplo.com/imagen.jpg"}
            ),
        }

    def clean_sku(self):
        return self.cleaned_data["sku"].strip().upper()

