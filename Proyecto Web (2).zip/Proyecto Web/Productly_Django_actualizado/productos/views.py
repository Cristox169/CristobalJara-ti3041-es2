from decimal import Decimal

import django
from django.conf import settings
from django.contrib.messages.views import SuccessMessageMixin
from django.db.models import Q, Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import (
    CreateView,
    DeleteView,
    DetailView,
    ListView,
    TemplateView,
    UpdateView,
)

from .forms import ProductoForm
from .models import Producto


class InicioView(TemplateView):
    template_name = "inicio.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        productos = Producto.objects.all()
        context.update(
            {
                "total_productos": productos.count(),
                "productos_activos": productos.filter(activo=True).count(),
                "unidades_stock": productos.aggregate(total=Sum("stock"))["total"] or 0,
                "ultimos_productos": productos.order_by("-creado")[:4],
            }
        )
        return context


class ProductoListView(ListView):
    model = Producto
    template_name = "productos/lista.html"
    context_object_name = "productos"
    paginate_by = 9

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        categoria = self.request.GET.get("categoria", "").strip()
        orden = self.request.GET.get("orden", "nombre")

        if query:
            queryset = queryset.filter(
                Q(nombre__icontains=query)
                | Q(sku__icontains=query)
                | Q(descripcion__icontains=query)
            )
        if categoria:
            queryset = queryset.filter(categoria=categoria)

        order_fields = {
            "nombre": "nombre",
            "precio_asc": "precio",
            "precio_desc": "-precio",
            "recientes": "-creado",
            "stock": "-stock",
        }
        return queryset.order_by(order_fields.get(orden, "nombre"))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "categorias": Producto.Categoria.choices,
                "q": self.request.GET.get("q", ""),
                "categoria_actual": self.request.GET.get("categoria", ""),
                "orden_actual": self.request.GET.get("orden", "nombre"),
            }
        )
        return context


class ProductoDetailView(DetailView):
    model = Producto
    template_name = "productos/detalle.html"
    context_object_name = "producto"


class ProductoCreateView(SuccessMessageMixin, CreateView):
    model = Producto
    form_class = ProductoForm
    template_name = "productos/formulario.html"
    success_message = "Producto creado correctamente."


class ProductoUpdateView(SuccessMessageMixin, UpdateView):
    model = Producto
    form_class = ProductoForm
    template_name = "productos/formulario.html"
    success_message = "Producto actualizado correctamente."


class ProductoDeleteView(DeleteView):
    model = Producto
    template_name = "productos/confirmar_eliminar.html"
    success_url = reverse_lazy("productos:lista")
    context_object_name = "producto"


class ConfiguracionView(TemplateView):
    template_name = "configuracion.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["runtime"] = {
            "django": django.get_version(),
            "base_datos": settings.DATABASES["default"]["ENGINE"].split(".")[-1],
            "idioma": settings.LANGUAGE_CODE,
            "zona_horaria": settings.TIME_ZONE,
            "modo_debug": settings.DEBUG,
        }
        return context


def api_productos(request):
    productos = Producto.objects.order_by("nombre")
    data = [
        {
            "id": producto.pk,
            "nombre": producto.nombre,
            "sku": producto.sku,
            "categoria": producto.categoria,
            "categoria_nombre": producto.get_categoria_display(),
            "precio": str(producto.precio.quantize(Decimal("0.01"))),
            "stock": producto.stock,
            "activo": producto.activo,
            "disponible": producto.disponible,
        }
        for producto in productos
    ]
    return JsonResponse({"total": len(data), "productos": data}, json_dumps_params={"ensure_ascii": False})


def api_producto_detalle(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    return JsonResponse(
        {
            "id": producto.pk,
            "nombre": producto.nombre,
            "sku": producto.sku,
            "descripcion": producto.descripcion,
            "categoria": producto.get_categoria_display(),
            "precio": str(producto.precio),
            "stock": producto.stock,
            "imagen_url": producto.imagen_url,
            "activo": producto.activo,
            "creado": producto.creado.isoformat(),
            "actualizado": producto.actualizado.isoformat(),
        },
        json_dumps_params={"ensure_ascii": False},
    )
