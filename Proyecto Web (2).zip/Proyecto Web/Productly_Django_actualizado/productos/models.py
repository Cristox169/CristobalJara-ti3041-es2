from django.core.validators import MinValueValidator
from django.db import models
from django.urls import reverse


class Producto(models.Model):
    class Categoria(models.TextChoices):
        TECNOLOGIA = "tecnologia", "Tecnología"
        HOGAR = "hogar", "Hogar"
        OFICINA = "oficina", "Oficina"
        DEPORTE = "deporte", "Deporte"
        OTROS = "otros", "Otros"

    nombre = models.CharField(max_length=120)
    sku = models.CharField("SKU", max_length=30, unique=True)
    descripcion = models.TextField(blank=True)
    categoria = models.CharField(
        max_length=20,
        choices=Categoria.choices,
        default=Categoria.OTROS,
    )
    precio = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)],
    )
    stock = models.PositiveIntegerField(default=0)
    imagen_url = models.URLField("URL de imagen", blank=True)
    activo = models.BooleanField(default=True)
    creado = models.DateTimeField(auto_now_add=True)
    actualizado = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["nombre"]
        verbose_name = "producto"
        verbose_name_plural = "productos"

    def __str__(self):
        return f"{self.nombre} ({self.sku})"

    def get_absolute_url(self):
        return reverse("productos:detalle", kwargs={"pk": self.pk})

    @property
    def disponible(self):
        return self.activo and self.stock > 0

