from django.contrib import admin

from .models import Producto


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "sku", "categoria", "precio", "stock", "activo")
    list_filter = ("categoria", "activo")
    search_fields = ("nombre", "sku", "descripcion")
    list_editable = ("precio", "stock", "activo")
    readonly_fields = ("creado", "actualizado")


admin.site.site_header = "Administración Productly"
admin.site.site_title = "Productly"
admin.site.index_title = "Gestión del catálogo"

