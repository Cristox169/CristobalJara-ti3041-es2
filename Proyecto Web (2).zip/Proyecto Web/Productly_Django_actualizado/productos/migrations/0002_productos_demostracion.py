from django.db import migrations


def crear_productos(apps, schema_editor):
    Producto = apps.get_model("productos", "Producto")
    demostracion = [
        {
            "nombre": "Teclado mecánico Nómada",
            "sku": "TEC-001",
            "descripcion": "Teclado compacto con conexión inalámbrica y retroiluminación cálida.",
            "categoria": "tecnologia",
            "precio": "64990.00",
            "stock": 14,
        },
        {
            "nombre": "Lámpara de escritorio Aura",
            "sku": "HOG-002",
            "descripcion": "Luz LED regulable con brazo articulado y acabado mate.",
            "categoria": "hogar",
            "precio": "28990.00",
            "stock": 9,
        },
        {
            "nombre": "Cuaderno de proyecto Lino",
            "sku": "OFI-003",
            "descripcion": "Cuaderno cosido de 160 páginas punteadas para ideas y planificación.",
            "categoria": "oficina",
            "precio": "12990.00",
            "stock": 32,
        },
        {
            "nombre": "Botella térmica Trek",
            "sku": "DEP-004",
            "descripcion": "Botella de acero inoxidable de 750 ml para actividades al aire libre.",
            "categoria": "deporte",
            "precio": "21990.00",
            "stock": 0,
        },
    ]
    for producto in demostracion:
        Producto.objects.get_or_create(sku=producto["sku"], defaults=producto)


def eliminar_productos(apps, schema_editor):
    Producto = apps.get_model("productos", "Producto")
    Producto.objects.filter(sku__in=["TEC-001", "HOG-002", "OFI-003", "DEP-004"]).delete()


class Migration(migrations.Migration):
    dependencies = [("productos", "0001_initial")]
    operations = [migrations.RunPython(crear_productos, eliminar_productos)]

