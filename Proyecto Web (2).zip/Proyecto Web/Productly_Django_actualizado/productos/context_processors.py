import json
from functools import lru_cache
from pathlib import Path

from django.conf import settings
from django.urls import NoReverseMatch, reverse
from django.utils import timezone


@lru_cache(maxsize=1)
def _read_site_config():
    config_path = Path(settings.ROOT_DIR) / "json" / "site.json"
    with config_path.open(encoding="utf-8") as config_file:
        return json.load(config_file)


def site_navigation(request):
    config = _read_site_config()
    navigation = []
    for item in config.get("navigation", []):
        try:
            item = {**item, "url": reverse(item["route"])}
        except NoReverseMatch:
            continue
        navigation.append(item)

    return {
        "SITE_CONFIG": config,
        "NAV_ITEMS": navigation,
        "CURRENT_YEAR": timezone.localdate().year,
    }

