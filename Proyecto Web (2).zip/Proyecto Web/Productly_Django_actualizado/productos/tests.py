from django.test import TestCase
from django.urls import reverse

from .models import Producto


class ProductoViewsTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.producto, _ = Producto.objects.update_or_create(
            sku="TEC-001",
            defaults={
                "nombre": "Teclado mecánico",
                "descripcion": "Teclado para pruebas",
                "categoria": Producto.Categoria.TECNOLOGIA,
                "precio": "49990.00",
                "stock": 8,
            },
        )

    def test_inicio_responde(self):
        response = self.client.get(reverse("productos:inicio"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Teclado mecánico")

    def test_catalogo_filtra_por_busqueda(self):
        response = self.client.get(reverse("productos:lista"), {"q": "mecánico"})
        self.assertContains(response, self.producto.nombre)

    def test_crear_producto(self):
        response = self.client.post(
            reverse("productos:crear"),
            {
                "nombre": "Lámpara de escritorio",
                "sku": "hog-099",
                "descripcion": "Luz LED",
                "categoria": Producto.Categoria.HOGAR,
                "precio": "19990.00",
                "stock": 4,
                "imagen_url": "",
                "activo": True,
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Producto.objects.filter(sku="HOG-099").exists())

    def test_api_devuelve_json(self):
        response = self.client.get(reverse("productos:api_productos"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["total"], Producto.objects.count())
        self.assertTrue(
            any(item["sku"] == "TEC-001" for item in response.json()["productos"])
        )
