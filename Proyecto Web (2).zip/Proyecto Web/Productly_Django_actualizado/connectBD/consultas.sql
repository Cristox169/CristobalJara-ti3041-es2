-- Consultas centralizadas del proyecto Productly (SQLite).
-- Django utiliza su ORM; este archivo documenta las consultas SQL equivalentes
-- para análisis, soporte o ejecución manual en DB Browser for SQLite.

-- Listado general de productos.
SELECT id, nombre, sku, categoria, precio, stock, activo, creado, actualizado
FROM productos_producto
ORDER BY nombre ASC;

-- Buscar por nombre, SKU o descripción. Reemplazar :termino por el texto buscado.
SELECT *
FROM productos_producto
WHERE nombre LIKE '%' || :termino || '%'
   OR sku LIKE '%' || :termino || '%'
   OR descripcion LIKE '%' || :termino || '%'
ORDER BY nombre ASC;

-- Resumen de inventario por categoría.
SELECT categoria,
       COUNT(*) AS cantidad_productos,
       SUM(stock) AS unidades,
       ROUND(SUM(precio * stock), 2) AS valor_inventario
FROM productos_producto
WHERE activo = 1
GROUP BY categoria
ORDER BY categoria;

-- Productos con stock bajo.
SELECT id, nombre, sku, stock
FROM productos_producto
WHERE activo = 1 AND stock <= :limite
ORDER BY stock ASC, nombre ASC;

