#!/usr/bin/env python
"""Utilidad de línea de comandos para el proyecto Django."""
import os
import sys


def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "No se pudo importar Django. Activa el entorno virtual .venv."
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()

