from datetime import timedelta
from decimal import Decimal

from django import forms
from django.db import transaction
from django.utils import timezone

from .models import Bodega, ListaPrecio, MovimientoInventario, PrecioProducto, Producto


class ProductoForm(forms.ModelForm):
    precio_venta = forms.DecimalField(
        label="Precio de venta",
        min_value=0,
        max_digits=12,
        decimal_places=2,
        widget=forms.NumberInput(attrs={"min": 0, "step": "1"}),
    )
    lista_precio = forms.ModelChoiceField(label="Lista de precios", queryset=ListaPrecio.objects.none())
    ajuste_stock = forms.DecimalField(
        label="Movimiento de stock",
        required=False,
        initial=0,
        max_digits=12,
        decimal_places=2,
        help_text="Use un valor positivo para ingresar stock o negativo para descontarlo.",
        widget=forms.NumberInput(attrs={"step": "1"}),
    )
    bodega = forms.ModelChoiceField(
        label="Bodega del movimiento",
        queryset=Bodega.objects.none(),
        required=False,
    )

    class Meta:
        model = Producto
        fields = [
            "sku",
            "nombre",
            "descripcion",
            "categoria",
            "marca",
            "unidad",
            "punto_reorden",
            "imagen_url",
            "activo",
        ]
        widgets = {
            "sku": forms.TextInput(attrs={"placeholder": "Ej. HER-001"}),
            "nombre": forms.TextInput(attrs={"placeholder": "Ej. Martillo carpintero 16 oz"}),
            "descripcion": forms.Textarea(attrs={"rows": 4, "placeholder": "Uso y características principales"}),
            "punto_reorden": forms.NumberInput(attrs={"min": 0}),
            "imagen_url": forms.URLInput(attrs={"placeholder": "https://ejemplo.com/imagen.jpg"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["lista_precio"].queryset = ListaPrecio.objects.filter(activa=True)
        self.fields["bodega"].queryset = Bodega.objects.filter(activa=True)
        if self.instance.pk:
            precio = self.instance.precios.filter(lista__activa=True).order_by("-vigente_desde").first()
            if precio:
                self.fields["precio_venta"].initial = precio.monto
                self.fields["lista_precio"].initial = precio.lista

    def clean_sku(self):
        return self.cleaned_data["sku"].strip().upper()

    def clean(self):
        cleaned = super().clean()
        ajuste = cleaned.get("ajuste_stock") or Decimal("0")
        if ajuste and not cleaned.get("bodega"):
            self.add_error("bodega", "Seleccione una bodega para registrar el movimiento.")
        return cleaned

    @transaction.atomic
    def save(self, commit=True):
        producto = super().save(commit=commit)
        if not commit:
            return producto

        lista = self.cleaned_data["lista_precio"]
        monto = self.cleaned_data["precio_venta"]
        precio_actual = producto.precios.filter(lista=lista, vigente_hasta__isnull=True).order_by("-vigente_desde").first()
        if not precio_actual or precio_actual.monto != monto:
            hoy = timezone.localdate()
            if precio_actual and precio_actual.vigente_desde == hoy:
                precio_actual.monto = monto
                precio_actual.save(update_fields=["monto"])
            else:
                if precio_actual:
                    precio_actual.vigente_hasta = hoy - timedelta(days=1)
                    precio_actual.save(update_fields=["vigente_hasta"])
                PrecioProducto.objects.create(
                    producto=producto,
                    lista=lista,
                    monto=monto,
                    vigente_desde=hoy,
                )

        ajuste = self.cleaned_data.get("ajuste_stock") or Decimal("0")
        if ajuste:
            MovimientoInventario.objects.create(
                producto=producto,
                bodega=self.cleaned_data["bodega"],
                tipo=MovimientoInventario.Tipo.AJUSTE,
                cantidad=ajuste,
                costo_unitario=Decimal("0"),
                referencia="FORMULARIO-WEB",
                observacion="Ajuste registrado desde el mantenedor web",
            )
        return producto
