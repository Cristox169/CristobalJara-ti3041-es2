from decimal import Decimal

from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .management.commands.poblar_ferreteria import PRODUCTOS
from .models import (
    Bodega,
    Categoria,
    ListaPrecio,
    MovimientoInventario,
    PrecioProducto,
    Producto,
    UnidadMedida,
)


class ProductoViewsTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.categoria, _ = Categoria.objects.update_or_create(
            nombre="Herramientas manuales",
            defaults={"slug": "herramientas-manuales", "activa": True},
        )
        cls.unidad, _ = UnidadMedida.objects.get_or_create(
            simbolo="un", defaults={"nombre": "Unidad"}
        )
        cls.lista, _ = ListaPrecio.objects.get_or_create(
            nombre="Precio público", defaults={"moneda": "CLP", "activa": True}
        )
        cls.bodega, _ = Bodega.objects.update_or_create(
            codigo="BOD-TEST",
            defaults={"nombre": "Bodega de pruebas", "direccion": "Santiago"},
        )
        cls.producto, _ = Producto.objects.update_or_create(
            sku="TEC-001",
            defaults={
                "nombre": "Teclado mecánico",
                "descripcion": "Producto para pruebas",
                "categoria": cls.categoria,
                "unidad": cls.unidad,
                "punto_reorden": 3,
            },
        )
        PrecioProducto.objects.update_or_create(
            producto=cls.producto,
            lista=cls.lista,
            vigente_desde=timezone.localdate(),
            defaults={"monto": Decimal("49990")},
        )
        MovimientoInventario.objects.create(
            producto=cls.producto,
            bodega=cls.bodega,
            tipo=MovimientoInventario.Tipo.AJUSTE,
            cantidad=Decimal("8"),
            costo_unitario=Decimal("25000"),
            referencia="PRUEBA-INICIAL",
        )

    def test_inicio_responde_con_datos_de_base(self):
        response = self.client.get(reverse("productos:inicio"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Teclado mecánico")

    def test_catalogo_filtra_por_busqueda_y_categoria(self):
        response = self.client.get(
            reverse("productos:lista"),
            {"q": "mecánico", "categoria": self.categoria.slug},
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, self.producto.nombre)

    def test_crear_producto_registra_precio_y_stock(self):
        response = self.client.post(
            reverse("productos:crear"),
            {
                "nombre": "Martillo de prueba",
                "sku": "her-099",
                "descripcion": "Herramienta para prueba de integración",
                "categoria": self.categoria.pk,
                "unidad": self.unidad.pk,
                "marca": "",
                "punto_reorden": 2,
                "precio_venta": "19990.00",
                "lista_precio": self.lista.pk,
                "ajuste_stock": "4",
                "bodega": self.bodega.pk,
                "imagen_url": "",
                "activo": "on",
            },
        )
        self.assertEqual(response.status_code, 302)
        producto = Producto.objects.get(sku="HER-099")
        self.assertEqual(producto.precio_vigente, Decimal("19990.00"))
        self.assertEqual(producto.stock_total, Decimal("4"))

    def test_api_devuelve_valores_derivados(self):
        response = self.client.get(reverse("productos:api_productos"))
        self.assertEqual(response.status_code, 200)
        item = next(
            producto
            for producto in response.json()["productos"]
            if producto["sku"] == "TEC-001"
        )
        self.assertEqual(item["precio"], "49990")
        self.assertEqual(item["stock"], str(self.producto.stock_total))

    def test_modulos_operacionales_responden(self):
        for nombre in [
            "ventas",
            "logistica",
            "rrhh",
            "produccion",
            "finanzas",
            "configuracion",
        ]:
            with self.subTest(nombre=nombre):
                response = self.client.get(reverse(f"productos:{nombre}"))
                self.assertEqual(response.status_code, 200)


class PoblamientoTests(TestCase):
    def test_comando_es_idempotente_y_carga_40_productos_de_pauta(self):
        call_command("poblar_ferreteria", verbosity=0)
        call_command("poblar_ferreteria", verbosity=0)
        skus = [fila[0] for fila in PRODUCTOS]
        self.assertEqual(Producto.objects.filter(sku__in=skus).count(), 40)
        self.assertTrue(Producto.objects.get(sku="HER-001").precios.exists())
        self.assertGreater(Producto.objects.get(sku="HER-001").stock_total, 0)
