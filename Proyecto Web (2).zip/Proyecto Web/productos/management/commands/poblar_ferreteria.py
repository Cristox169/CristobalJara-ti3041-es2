from datetime import date, time, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone
from django.utils.text import slugify

from productos.models import (
    AsignacionTurno,
    Bodega,
    Cargo,
    Categoria,
    CategoriaFinanciera,
    CentroCosto,
    Cliente,
    Compra,
    ComponenteReceta,
    ConsumoProduccion,
    ContratoLaboral,
    Departamento,
    Despacho,
    DespachoVenta,
    DetalleCompra,
    DetalleVenta,
    Empleado,
    LiquidacionSueldo,
    ListaPrecio,
    Marca,
    MetodoPago,
    MovimientoInventario,
    OrdenProduccion,
    PagoVenta,
    PeriodoNomina,
    PrecioProducto,
    Producto,
    ProductoProveedor,
    Proveedor,
    RecetaProduccion,
    TransaccionFinanciera,
    Transportista,
    Turno,
    UnidadMedida,
    Venta,
)


PRODUCTOS = [
    ("HER-001", "Martillo carpintero 16 oz", "Herramientas manuales", "Stanley", "un", 12990, 7200, 24, 6, "Martillo con mango antideslizante para armado y carpintería."),
    ("HER-002", "Alicate universal 8 pulgadas", "Herramientas manuales", "Irwin", "un", 10990, 6100, 18, 5, "Alicate de acero cromo vanadio para corte y sujeción."),
    ("HER-003", "Juego destornilladores 6 piezas", "Herramientas manuales", "Bahco", "set", 18990, 11200, 16, 4, "Set plano y Phillips con mangos ergonómicos."),
    ("HER-004", "Llave ajustable 10 pulgadas", "Herramientas manuales", "Bahco", "un", 15990, 9300, 13, 4, "Llave cromada de apertura graduable."),
    ("HER-005", "Serrucho profesional 20 pulgadas", "Herramientas manuales", "Stanley", "un", 16990, 9900, 11, 3, "Serrucho de triple filo para cortes rápidos en madera."),
    ("ELE-001", "Taladro percutor 13 mm 750 W", "Herramientas eléctricas", "Bosch", "un", 79990, 57500, 10, 3, "Taladro reversible con velocidad variable y mango auxiliar."),
    ("ELE-002", "Esmeril angular 4 1/2 pulgadas", "Herramientas eléctricas", "Makita", "un", 69990, 49800, 8, 3, "Esmeril compacto para corte y desbaste de metal."),
    ("ELE-003", "Sierra circular 7 1/4 pulgadas", "Herramientas eléctricas", "DeWalt", "un", 119990, 86500, 6, 2, "Sierra de alta potencia con guía paralela."),
    ("ELE-004", "Atornillador inalámbrico 12 V", "Herramientas eléctricas", "Bosch", "un", 64990, 45900, 12, 3, "Atornillador compacto con dos baterías y maleta."),
    ("ELE-005", "Lijadora orbital 220 W", "Herramientas eléctricas", "Makita", "un", 58990, 42100, 7, 2, "Lijadora con sistema de recolección de polvo."),
    ("FIJ-001", "Tornillo madera 8x1 1/2 caja 100", "Fijaciones", "Fixser", "caja", 5990, 3100, 36, 10, "Tornillo zincado punta aguja para madera."),
    ("FIJ-002", "Tarugo nylon 8 mm bolsa 50", "Fijaciones", "Fischer", "bolsa", 4990, 2700, 42, 12, "Tarugo universal para hormigón y albañilería."),
    ("FIJ-003", "Perno hexagonal M8 caja 100", "Fijaciones", "Fixser", "caja", 14990, 8900, 15, 5, "Perno galvanizado con tuerca y golilla."),
    ("FIJ-004", "Clavo corriente 2 pulgadas 1 kg", "Fijaciones", "Mamut", "kg", 3990, 2200, 28, 8, "Clavo de acero para trabajos generales."),
    ("FIJ-005", "Remache pop 4x10 mm caja 100", "Fijaciones", "Fixser", "caja", 7990, 4400, 19, 5, "Remache de aluminio para uniones livianas."),
    ("PIN-001", "Pintura látex interior blanco 1 galón", "Pinturas", "Ceresita", "gal", 24990, 17400, 14, 4, "Látex lavable de terminación mate para interior."),
    ("PIN-002", "Esmalte al agua semibrillo 1 galón", "Pinturas", "Tricolor", "gal", 32990, 23500, 9, 3, "Esmalte de bajo olor para madera y metal."),
    ("PIN-003", "Brocha profesional 3 pulgadas", "Pinturas", "Condor", "un", 6990, 3700, 31, 8, "Brocha de fibra sintética para terminaciones uniformes."),
    ("PIN-004", "Rodillo antigota 18 cm", "Pinturas", "Condor", "un", 5990, 3200, 25, 7, "Rodillo para superficies lisas y pinturas al agua."),
    ("PIN-005", "Diluyente sintético 1 litro", "Pinturas", "Sipa", "lt", 4990, 2900, 20, 6, "Diluyente para esmaltes y limpieza de herramientas."),
    ("ELEC-001", "Cable eléctrico EVA 2.5 mm 100 m", "Electricidad", "Nexans", "rollo", 89990, 67200, 5, 2, "Cable libre de halógenos para circuitos domiciliarios."),
    ("ELEC-002", "Interruptor simple embutido", "Electricidad", "Bticino", "un", 3990, 2100, 38, 10, "Interruptor modular blanco de 10 A."),
    ("ELEC-003", "Enchufe doble 10 A", "Electricidad", "Bticino", "un", 5990, 3300, 33, 9, "Tomacorriente doble con placa blanca."),
    ("ELEC-004", "Automático monopolar 16 A", "Electricidad", "Schneider", "un", 8990, 5200, 17, 5, "Interruptor termomagnético para tablero domiciliario."),
    ("ELEC-005", "Ampolleta LED 12 W luz cálida", "Electricidad", "Philips", "un", 2990, 1500, 45, 12, "Ampolleta eficiente base E27."),
    ("GAS-001", "Llave paso bola 1/2 pulgada", "Gasfitería", "Nibsa", "un", 6990, 3900, 22, 6, "Válvula de bronce para agua fría y caliente."),
    ("GAS-002", "Tubo PVC sanitario 110 mm 6 m", "Gasfitería", "Vinilit", "un", 26990, 19800, 10, 3, "Tubería sanitaria gris de unión cementada."),
    ("GAS-003", "Codo PVC sanitario 110 mm 90 grados", "Gasfitería", "Vinilit", "un", 4990, 2800, 26, 7, "Accesorio sanitario para cambio de dirección."),
    ("GAS-004", "Flexible agua HI-HI 1/2 40 cm", "Gasfitería", "Nibsa", "un", 3990, 2100, 30, 8, "Flexible trenzado para artefactos sanitarios."),
    ("GAS-005", "Cinta teflón 12 mm", "Gasfitería", "Genérico", "un", 990, 380, 60, 15, "Sellador de roscas para instalaciones de agua."),
    ("SEG-001", "Guante cabritilla reforzado", "Seguridad industrial", "Steelpro", "par", 4990, 2700, 35, 10, "Guante de cuero para manipulación y construcción."),
    ("SEG-002", "Lente seguridad transparente", "Seguridad industrial", "3M", "un", 3990, 2200, 40, 10, "Protección ocular con filtro UV y tratamiento antiempaño."),
    ("SEG-003", "Casco seguridad amarillo", "Seguridad industrial", "Steelpro", "un", 8990, 5100, 18, 5, "Casco ajustable para faenas y construcción."),
    ("SEG-004", "Protector auditivo tipo copa", "Seguridad industrial", "3M", "un", 18990, 12500, 12, 4, "Protección auditiva de alta atenuación."),
    ("SEG-005", "Mascarilla respirador reutilizable", "Seguridad industrial", "3M", "un", 29990, 21100, 9, 3, "Respirador de media cara para filtros reemplazables."),
    ("CON-001", "Cemento especial saco 25 kg", "Construcción", "Melón", "saco", 6990, 5100, 48, 14, "Cemento para morteros y hormigones de uso general."),
    ("CON-002", "Adhesivo cerámico saco 25 kg", "Construcción", "Bekron", "saco", 9990, 7200, 32, 9, "Adhesivo para cerámicos en pisos y muros."),
    ("CON-003", "Silicona neutra transparente 300 ml", "Construcción", "Sika", "un", 5990, 3400, 27, 8, "Sellador flexible para vidrio, aluminio y baños."),
    ("TAL-001", "Perfil ángulo perforado 2 m", "Organización y taller", "Mamut", "un", 7990, 4700, 30, 8, "Perfil galvanizado para estructuras y estanterías."),
    ("TAL-002", "Estante metálico 5 niveles", "Organización y taller", "Mamut", "un", 79990, 55800, 4, 2, "Estante armable de carga media para bodega y taller."),
]

PRODUCTOS_DEMO_ANTERIORES = ["TEC-001", "HOG-002", "OFI-003", "DEP-004"]


class Command(BaseCommand):
    help = "Carga 40 productos chilenos y datos operacionales de demostración sin duplicar registros."

    @transaction.atomic
    def handle(self, *args, **options):
        Producto.objects.filter(sku__in=PRODUCTOS_DEMO_ANTERIORES).update(activo=False)
        categorias = {}
        for nombre in sorted({fila[2] for fila in PRODUCTOS}):
            categorias[nombre], _ = Categoria.objects.update_or_create(slug=slugify(nombre), defaults={"nombre": nombre, "activa": True})

        marcas = {}
        paises = {"Bosch": "Alemania", "Makita": "Japón", "DeWalt": "Estados Unidos", "Bahco": "Suecia", "Stanley": "Estados Unidos", "3M": "Estados Unidos"}
        for nombre in sorted({fila[3] for fila in PRODUCTOS}):
            marcas[nombre], _ = Marca.objects.update_or_create(nombre=nombre, defaults={"pais_origen": paises.get(nombre, "Chile")})

        unidades = {}
        nombres_unidad = {"un": "Unidad", "set": "Set", "caja": "Caja", "bolsa": "Bolsa", "kg": "Kilogramo", "gal": "Galón", "lt": "Litro", "rollo": "Rollo", "par": "Par", "saco": "Saco"}
        for simbolo in sorted({fila[4] for fila in PRODUCTOS}):
            unidades[simbolo], _ = UnidadMedida.objects.update_or_create(simbolo=simbolo, defaults={"nombre": nombres_unidad[simbolo]})

        lista, _ = ListaPrecio.objects.update_or_create(nombre="Precio público", defaults={"moneda": "CLP", "activa": True})
        central, _ = Bodega.objects.update_or_create(codigo="BOD-CENTRAL", defaults={"nombre": "Bodega Central Santiago", "direccion": "Av. Matta 1840, Santiago", "activa": True})
        norte, _ = Bodega.objects.update_or_create(codigo="BOD-NORTE", defaults={"nombre": "Bodega Zona Norte", "direccion": "Av. Américo Vespucio 1250, Quilicura", "activa": True})
        Bodega.objects.update_or_create(codigo="TIENDA-01", defaults={"nombre": "Sala de venta principal", "direccion": "Av. Matta 1840, Santiago", "activa": True})

        proveedores_datos = [
            ("76.111.111-1", "Distribuidora Andes SpA", "ventas@andes.cl", "+56 2 2400 1100"),
            ("76.222.222-2", "Herramientas del Pacífico Ltda.", "pedidos@pacifico.cl", "+56 2 2500 2200"),
            ("76.333.333-3", "Suministros Técnicos Chile", "contacto@sutech.cl", "+56 2 2600 3300"),
            ("76.444.444-4", "Importadora Maestro Sur", "comercial@maestrosur.cl", "+56 2 2700 4400"),
        ]
        proveedores = []
        for rut, razon, email, telefono in proveedores_datos:
            proveedor, _ = Proveedor.objects.update_or_create(rut=rut, defaults={"razon_social": razon, "email": email, "telefono": telefono, "direccion": "Región Metropolitana", "activo": True})
            proveedores.append(proveedor)

        productos = {}
        hoy = timezone.localdate()
        for indice, (sku, nombre, categoria, marca, unidad, precio, costo, stock, reorden, descripcion) in enumerate(PRODUCTOS):
            producto, _ = Producto.objects.update_or_create(
                sku=sku,
                defaults={
                    "nombre": nombre,
                    "descripcion": descripcion,
                    "categoria": categorias[categoria],
                    "marca": marcas[marca],
                    "unidad": unidades[unidad],
                    "punto_reorden": reorden,
                    "activo": True,
                },
            )
            productos[sku] = producto
            PrecioProducto.objects.update_or_create(producto=producto, lista=lista, vigente_desde=hoy, defaults={"monto": precio, "vigente_hasta": None})
            MovimientoInventario.objects.update_or_create(
                producto=producto,
                bodega=central if indice % 3 else norte,
                referencia=f"CARGA-IA-{sku}",
                defaults={"tipo": MovimientoInventario.Tipo.AJUSTE, "cantidad": stock, "costo_unitario": costo, "observacion": "Poblamiento inicial generado con IA"},
            )
            proveedor = proveedores[indice % len(proveedores)]
            ProductoProveedor.objects.update_or_create(
                producto=producto,
                proveedor=proveedor,
                defaults={"codigo_proveedor": f"PRV-{sku}", "plazo_entrega_dias": 2 + indice % 6, "costo_ultimo": costo, "preferente": True},
            )

        clientes = []
        for rut, nombre, tipo, email in [
            ("15.111.111-1", "Camila Rojas", "PERSONA", "camila@example.cl"),
            ("16.222.222-2", "Diego Muñoz", "PERSONA", "diego@example.cl"),
            ("77.333.333-3", "Constructora Horizonte SpA", "EMPRESA", "compras@horizonte.cl"),
            ("77.444.444-4", "Servicios Mantención Sur Ltda.", "EMPRESA", "operaciones@mantencionsur.cl"),
            ("17.555.555-5", "Valentina Soto", "PERSONA", "valentina@example.cl"),
        ]:
            cliente, _ = Cliente.objects.update_or_create(rut=rut, defaults={"nombre": nombre, "tipo": tipo, "email": email, "telefono": "+56 9 5000 0000"})
            clientes.append(cliente)

        efectivo, _ = MetodoPago.objects.get_or_create(nombre="Efectivo")
        tarjeta, _ = MetodoPago.objects.get_or_create(nombre="Tarjeta")
        transferencia, _ = MetodoPago.objects.get_or_create(nombre="Transferencia")
        ahora = timezone.now()
        ventas_datos = [
            ("V-0001", 0, [("HER-001", 2), ("FIJ-001", 3)], tarjeta),
            ("V-0002", 2, [("ELE-001", 1), ("SEG-001", 4), ("SEG-002", 4)], transferencia),
            ("V-0003", 1, [("PIN-001", 2), ("PIN-003", 2)], efectivo),
            ("V-0004", 3, [("GAS-002", 3), ("GAS-003", 6), ("GAS-005", 8)], transferencia),
            ("V-0005", 4, [("ELEC-002", 4), ("ELEC-003", 3)], tarjeta),
            ("V-0006", 2, [("CON-001", 10), ("CON-002", 5)], transferencia),
        ]
        ventas = []
        for indice, (numero, cliente_idx, lineas, metodo) in enumerate(ventas_datos):
            fecha = ahora - timedelta(days=indice * 3)
            venta, _ = Venta.objects.update_or_create(numero=numero, defaults={"cliente": clientes[cliente_idx], "fecha": fecha, "estado": Venta.Estado.PAGADA, "descuento": 0})
            ventas.append(venta)
            total = Decimal("0")
            for sku, cantidad in lineas:
                datos = next(f for f in PRODUCTOS if f[0] == sku)
                detalle, _ = DetalleVenta.objects.update_or_create(venta=venta, producto=productos[sku], defaults={"cantidad": cantidad, "precio_unitario": datos[5], "costo_unitario": datos[6]})
                total += detalle.subtotal
                MovimientoInventario.objects.update_or_create(
                    producto=productos[sku], bodega=central, referencia=f"{numero}-{sku}",
                    defaults={"tipo": MovimientoInventario.Tipo.VENTA, "cantidad": -Decimal(cantidad), "costo_unitario": datos[6], "fecha": fecha, "observacion": "Salida asociada a venta"},
                )
            PagoVenta.objects.update_or_create(venta=venta, metodo=metodo, referencia=f"PAGO-{numero}", defaults={"monto": total, "fecha": fecha})

        compras_datos = [
            ("OC-0001", 0, central, [("HER-001", 12), ("FIJ-001", 20)]),
            ("OC-0002", 1, norte, [("ELE-001", 5), ("ELE-002", 5)]),
            ("OC-0003", 2, central, [("CON-001", 30), ("CON-002", 20)]),
        ]
        compras = []
        for indice, (numero, proveedor_idx, bodega, lineas) in enumerate(compras_datos):
            fecha = ahora - timedelta(days=20 + indice * 4)
            compra, _ = Compra.objects.update_or_create(numero=numero, defaults={"proveedor": proveedores[proveedor_idx], "bodega": bodega, "fecha": fecha, "estado": Compra.Estado.RECIBIDA})
            compras.append(compra)
            for sku, cantidad in lineas:
                datos = next(f for f in PRODUCTOS if f[0] == sku)
                DetalleCompra.objects.update_or_create(compra=compra, producto=productos[sku], defaults={"cantidad": cantidad, "costo_unitario": datos[6]})
                MovimientoInventario.objects.update_or_create(
                    producto=productos[sku], bodega=bodega, referencia=f"{numero}-{sku}",
                    defaults={"tipo": MovimientoInventario.Tipo.COMPRA, "cantidad": cantidad, "costo_unitario": datos[6], "fecha": fecha, "observacion": "Recepción de compra"},
                )

        departamentos = {}
        for nombre in ["Ventas", "Logística", "Administración y Finanzas", "Producción"]:
            departamentos[nombre], _ = Departamento.objects.get_or_create(nombre=nombre)
        cargos = {}
        for depto, nombre in [("Ventas", "Vendedor"), ("Logística", "Encargado de bodega"), ("Administración y Finanzas", "Analista contable"), ("Producción", "Maestro de taller")]:
            cargos[nombre], _ = Cargo.objects.get_or_create(departamento=departamentos[depto], nombre=nombre)
        empleados_datos = [
            ("18.101.101-1", "Ana", "Pérez Soto", "ana.perez@ferreteriacentral.cl", "Vendedor", 750000),
            ("17.202.202-2", "Mauricio", "Lagos Díaz", "mauricio.lagos@ferreteriacentral.cl", "Encargado de bodega", 880000),
            ("19.303.303-3", "Francisca", "Vera Ríos", "francisca.vera@ferreteriacentral.cl", "Analista contable", 1050000),
            ("16.404.404-4", "Pedro", "Araya León", "pedro.araya@ferreteriacentral.cl", "Maestro de taller", 920000),
        ]
        empleados = []
        contratos = []
        for rut, nombres, apellidos, email, cargo, sueldo in empleados_datos:
            empleado, _ = Empleado.objects.update_or_create(rut=rut, defaults={"nombres": nombres, "apellidos": apellidos, "email": email, "telefono": "+56 9 6000 0000", "fecha_ingreso": date(2025, 3, 1), "activo": True})
            empleados.append(empleado)
            contrato, _ = ContratoLaboral.objects.update_or_create(empleado=empleado, fecha_inicio=date(2025, 3, 1), defaults={"cargo": cargos[cargo], "fecha_fin": None, "sueldo_base": sueldo, "horas_semanales": 44})
            contratos.append(contrato)
        turno, _ = Turno.objects.get_or_create(nombre="Jornada diurna", defaults={"hora_inicio": time(8, 30), "hora_fin": time(17, 30)})
        for empleado in empleados:
            AsignacionTurno.objects.update_or_create(empleado=empleado, fecha=hoy, defaults={"turno": turno})

        periodo_inicio = hoy.replace(day=1)
        periodo_fin = (periodo_inicio + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        periodo, _ = PeriodoNomina.objects.update_or_create(
            nombre=f"Nómina {periodo_inicio:%Y-%m}",
            defaults={
                "fecha_inicio": periodo_inicio,
                "fecha_fin": periodo_fin,
                "estado": PeriodoNomina.Estado.CERRADO,
            },
        )
        for contrato in contratos:
            descuentos = (contrato.sueldo_base * Decimal("0.10")).quantize(Decimal("1"))
            LiquidacionSueldo.objects.update_or_create(
                periodo=periodo,
                contrato=contrato,
                defaults={
                    "total_haberes": contrato.sueldo_base,
                    "total_descuentos": descuentos,
                    "liquido": contrato.sueldo_base - descuentos,
                },
            )

        receta, _ = RecetaProduccion.objects.update_or_create(codigo="REC-EST-01", version=1, defaults={"producto_terminado": productos["TAL-002"], "rendimiento": 1, "activa": True})
        ComponenteReceta.objects.update_or_create(receta=receta, componente=productos["TAL-001"], defaults={"cantidad": Decimal("4")})
        ComponenteReceta.objects.update_or_create(receta=receta, componente=productos["FIJ-003"], defaults={"cantidad": Decimal("0.20")})
        orden, _ = OrdenProduccion.objects.update_or_create(numero="OP-0001", defaults={"receta": receta, "bodega": central, "cantidad_planificada": 5, "cantidad_producida": 2, "fecha_inicio": hoy - timedelta(days=2), "estado": OrdenProduccion.Estado.PROCESO})
        ConsumoProduccion.objects.update_or_create(orden=orden, producto=productos["TAL-001"], defaults={"cantidad": 8, "costo_unitario": 4700})
        ConsumoProduccion.objects.update_or_create(orden=orden, producto=productos["FIJ-003"], defaults={"cantidad": Decimal("0.40"), "costo_unitario": 8900})

        transportista, _ = Transportista.objects.update_or_create(rut="14.555.555-5", defaults={"nombre": "Carlos Medina", "patente": "KLBR22", "telefono": "+56 9 7000 0000"})
        despacho, _ = Despacho.objects.update_or_create(numero="DES-0001", defaults={"transportista": transportista, "fecha": ahora, "estado": Despacho.Estado.RUTA, "costo": 8500})
        DespachoVenta.objects.update_or_create(despacho=despacho, venta=ventas[1])

        centros = {}
        for codigo, nombre in [("CC-VTA", "Ventas"), ("CC-LOG", "Logística"), ("CC-RRHH", "Recursos humanos"), ("CC-PROD", "Producción")]:
            centros[codigo], _ = CentroCosto.objects.update_or_create(codigo=codigo, defaults={"nombre": nombre})
        categorias_fin = {}
        for codigo, nombre, tipo in [("ING-VTA", "Ingresos por ventas", "INGRESO"), ("COS-MER", "Costo de mercadería", "COSTO"), ("GAS-REM", "Remuneraciones", "GASTO"), ("GAS-DES", "Despachos", "GASTO")]:
            categorias_fin[codigo], _ = CategoriaFinanciera.objects.update_or_create(codigo=codigo, defaults={"nombre": nombre, "tipo": tipo})
        for venta in ventas:
            costo = sum((detalle.margen for detalle in venta.detalles.all()), Decimal("0"))
            costo_venta = venta.total - costo
            TransaccionFinanciera.objects.update_or_create(referencia=f"ING-{venta.numero}", defaults={"fecha": venta.fecha, "categoria": categorias_fin["ING-VTA"], "centro_costo": centros["CC-VTA"], "concepto": f"Ingreso venta {venta.numero}", "monto": venta.total})
            TransaccionFinanciera.objects.update_or_create(referencia=f"COSTO-{venta.numero}", defaults={"fecha": venta.fecha, "categoria": categorias_fin["COS-MER"], "centro_costo": centros["CC-VTA"], "concepto": f"Costo mercadería {venta.numero}", "monto": costo_venta})
        TransaccionFinanciera.objects.update_or_create(referencia="NOMINA-DEMO", defaults={"fecha": ahora, "categoria": categorias_fin["GAS-REM"], "centro_costo": centros["CC-RRHH"], "concepto": "Nómina base mensual", "monto": sum(Decimal(str(e[5])) for e in empleados_datos)})
        TransaccionFinanciera.objects.update_or_create(referencia="DES-DES-0001", defaults={"fecha": ahora, "categoria": categorias_fin["GAS-DES"], "centro_costo": centros["CC-LOG"], "concepto": "Despacho DES-0001", "monto": despacho.costo})

        self.stdout.write(self.style.SUCCESS(f"Poblamiento completado: {len(PRODUCTOS)} productos y datos de todas las áreas."))
