from django.db import migrations
from django.utils.text import slugify


def normalizar_productos(apps, schema_editor):
    Categoria = apps.get_model("productos", "Categoria")
    Marca = apps.get_model("productos", "Marca")
    UnidadMedida = apps.get_model("productos", "UnidadMedida")
    ListaPrecio = apps.get_model("productos", "ListaPrecio")
    PrecioProducto = apps.get_model("productos", "PrecioProducto")
    Bodega = apps.get_model("productos", "Bodega")
    MovimientoInventario = apps.get_model("productos", "MovimientoInventario")
    Producto = apps.get_model("productos", "Producto")

    nombres = {
        "tecnologia": "Herramientas eléctricas",
        "hogar": "Hogar y seguridad",
        "oficina": "Organización y taller",
        "deporte": "Protección personal",
        "otros": "Otros",
    }
    categorias = {}
    for clave, nombre in nombres.items():
        categorias[clave], _ = Categoria.objects.get_or_create(
            nombre=nombre,
            defaults={"slug": slugify(nombre), "activa": True},
        )

    unidad, _ = UnidadMedida.objects.get_or_create(nombre="Unidad", defaults={"simbolo": "un"})
    marca, _ = Marca.objects.get_or_create(nombre="Sin marca", defaults={"pais_origen": ""})
    lista, _ = ListaPrecio.objects.get_or_create(nombre="Precio público", defaults={"moneda": "CLP", "activa": True})
    bodega, _ = Bodega.objects.get_or_create(
        codigo="BOD-CENTRAL",
        defaults={"nombre": "Bodega central", "direccion": "Casa matriz", "activa": True},
    )

    for producto in Producto.objects.all():
        producto.categoria_normalizada = categorias.get(producto.categoria, categorias["otros"])
        producto.unidad = unidad
        producto.marca = marca
        producto.save(update_fields=["categoria_normalizada", "unidad", "marca"])
        PrecioProducto.objects.get_or_create(
            producto=producto,
            lista=lista,
            vigente_desde=producto.creado.date(),
            defaults={"monto": producto.precio},
        )
        if producto.stock:
            MovimientoInventario.objects.get_or_create(
                producto=producto,
                bodega=bodega,
                referencia="MIGRACION-LEGACY",
                defaults={
                    "tipo": "AJUSTE",
                    "cantidad": producto.stock,
                    "costo_unitario": producto.precio,
                    "fecha": producto.creado,
                    "observacion": "Stock migrado al modelo normalizado",
                },
            )


class Migration(migrations.Migration):
    dependencies = [("productos", "0003_estructura_5fn_inicial")]

    operations = [migrations.RunPython(normalizar_productos, migrations.RunPython.noop)]
