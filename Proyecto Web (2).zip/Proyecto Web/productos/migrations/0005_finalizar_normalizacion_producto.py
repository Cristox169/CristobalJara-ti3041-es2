import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("productos", "0004_normalizar_datos_existentes")]

    operations = [
        migrations.RemoveField(model_name="producto", name="categoria"),
        migrations.RemoveField(model_name="producto", name="precio"),
        migrations.RemoveField(model_name="producto", name="stock"),
        migrations.RenameField(
            model_name="producto",
            old_name="categoria_normalizada",
            new_name="categoria",
        ),
        migrations.AlterField(
            model_name="producto",
            name="categoria",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="productos",
                to="productos.categoria",
            ),
        ),
        migrations.AlterField(
            model_name="producto",
            name="unidad",
            field=models.ForeignKey(
                on_delete=django.db.models.deletion.PROTECT,
                related_name="productos",
                to="productos.unidadmedida",
            ),
        ),
    ]
