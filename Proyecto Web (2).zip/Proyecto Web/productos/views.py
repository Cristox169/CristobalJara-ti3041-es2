from decimal import Decimal

import django
from django.apps import apps
from django.conf import settings
from django.contrib.messages.views import SuccessMessageMixin
from django.db.models import DecimalField, ExpressionWrapper, F, OuterRef, Q, Subquery, Sum, Value
from django.db.models.functions import Coalesce
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import CreateView, DeleteView, DetailView, ListView, TemplateView, UpdateView

from .forms import ProductoForm
from .models import (
    Bodega,
    Compra,
    ContratoLaboral,
    DetalleCompra,
    DetalleVenta,
    Empleado,
    MovimientoInventario,
    OrdenProduccion,
    Producto,
    TransaccionFinanciera,
    Venta,
)


DECIMAL_FIELD = DecimalField(max_digits=16, decimal_places=2)


def productos_con_indicadores():
    from .models import PrecioProducto

    hoy = timezone.localdate()
    precio_subquery = PrecioProducto.objects.filter(
        producto=OuterRef("pk"),
        lista__activa=True,
        vigente_desde__lte=hoy,
    ).filter(Q(vigente_hasta__isnull=True) | Q(vigente_hasta__gte=hoy)).order_by("-vigente_desde").values("monto")[:1]
    return Producto.objects.filter(activo=True).select_related("categoria", "marca", "unidad").annotate(
        stock_db=Coalesce(Sum("movimientos__cantidad"), Value(Decimal("0")), output_field=DECIMAL_FIELD),
        precio_db=Coalesce(Subquery(precio_subquery, output_field=DECIMAL_FIELD), Value(Decimal("0")), output_field=DECIMAL_FIELD),
    )


def _suma_lineas(queryset, campo_precio):
    expresion = ExpressionWrapper(F("cantidad") * F(campo_precio), output_field=DECIMAL_FIELD)
    return queryset.aggregate(total=Coalesce(Sum(expresion), Value(Decimal("0")), output_field=DECIMAL_FIELD))["total"]


class InicioView(TemplateView):
    template_name = "inicio.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        productos = productos_con_indicadores()
        ventas_validas = DetalleVenta.objects.exclude(venta__estado=Venta.Estado.ANULADA)
        ingresos = _suma_lineas(ventas_validas, "precio_unitario")
        costo_ventas = _suma_lineas(ventas_validas, "costo_unitario")
        context.update(
            {
                "total_productos": productos.count(),
                "productos_activos": productos.filter(activo=True).count(),
                "unidades_stock": MovimientoInventario.objects.aggregate(total=Coalesce(Sum("cantidad"), Value(Decimal("0")), output_field=DECIMAL_FIELD))["total"],
                "ingresos": ingresos,
                "margen_bruto": ingresos - costo_ventas,
                "ventas_count": Venta.objects.exclude(estado=Venta.Estado.ANULADA).count(),
                "empleados_activos": Empleado.objects.filter(activo=True).count(),
                "ultimos_productos": productos.order_by("-creado")[:4],
                "ultimas_ventas": Venta.objects.select_related("cliente").prefetch_related("detalles").order_by("-fecha")[:5],
                "stock_bajo": productos.filter(stock_db__lte=F("punto_reorden"), activo=True).order_by("stock_db")[:5],
            }
        )
        return context


class ProductoListView(ListView):
    model = Producto
    template_name = "productos/lista.html"
    context_object_name = "productos"
    paginate_by = 12

    def get_queryset(self):
        queryset = productos_con_indicadores()
        query = self.request.GET.get("q", "").strip()
        categoria = self.request.GET.get("categoria", "").strip()
        orden = self.request.GET.get("orden", "nombre")
        if query:
            queryset = queryset.filter(Q(nombre__icontains=query) | Q(sku__icontains=query) | Q(descripcion__icontains=query) | Q(marca__nombre__icontains=query))
        if categoria:
            queryset = queryset.filter(categoria__slug=categoria)
        ordenes = {
            "nombre": "nombre",
            "precio_asc": "precio_db",
            "precio_desc": "-precio_db",
            "recientes": "-creado",
            "stock": "-stock_db",
        }
        return queryset.order_by(ordenes.get(orden, "nombre"))

    def get_context_data(self, **kwargs):
        from .models import Categoria

        context = super().get_context_data(**kwargs)
        context.update(
            {
                "categorias": Categoria.objects.filter(activa=True),
                "q": self.request.GET.get("q", ""),
                "categoria_actual": self.request.GET.get("categoria", ""),
                "orden_actual": self.request.GET.get("orden", "nombre"),
            }
        )
        return context


class ProductoDetailView(DetailView):
    model = Producto
    template_name = "productos/detalle.html"
    context_object_name = "producto"

    def get_queryset(self):
        return Producto.objects.select_related("categoria", "marca", "unidad").prefetch_related("precios__lista", "proveedores_producto__proveedor")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["stock_bodegas"] = Bodega.objects.filter(movimientos__producto=self.object).annotate(stock=Sum("movimientos__cantidad")).order_by("codigo")
        return context


class ProductoCreateView(SuccessMessageMixin, CreateView):
    model = Producto
    form_class = ProductoForm
    template_name = "productos/formulario.html"
    success_message = "Producto creado y movimientos registrados correctamente."


class ProductoUpdateView(SuccessMessageMixin, UpdateView):
    model = Producto
    form_class = ProductoForm
    template_name = "productos/formulario.html"
    success_message = "Producto actualizado correctamente."


class ProductoDeleteView(DeleteView):
    model = Producto
    template_name = "productos/confirmar_eliminar.html"
    success_url = reverse_lazy("productos:lista")
    context_object_name = "producto"


class VentasView(TemplateView):
    template_name = "modulos/ventas.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        lineas = DetalleVenta.objects.exclude(venta__estado=Venta.Estado.ANULADA)
        context.update(
            {
                "ventas": Venta.objects.select_related("cliente").prefetch_related("detalles").order_by("-fecha")[:20],
                "ingresos": _suma_lineas(lineas, "precio_unitario"),
                "costo_ventas": _suma_lineas(lineas, "costo_unitario"),
                "clientes": Venta.objects.values("cliente").distinct().count(),
            }
        )
        context["margen"] = context["ingresos"] - context["costo_ventas"]
        return context


class LogisticaView(TemplateView):
    template_name = "modulos/logistica.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        productos = productos_con_indicadores()
        compras_lineas = DetalleCompra.objects.exclude(compra__estado=Compra.Estado.ANULADA)
        context.update(
            {
                "bodegas": Bodega.objects.annotate(stock=Coalesce(Sum("movimientos__cantidad"), Value(Decimal("0")), output_field=DECIMAL_FIELD)).order_by("codigo"),
                "compras": Compra.objects.select_related("proveedor", "bodega").prefetch_related("detalles").order_by("-fecha")[:12],
                "costo_compras": _suma_lineas(compras_lineas, "costo_unitario"),
                "stock_bajo": productos.filter(stock_db__lte=F("punto_reorden"), activo=True).order_by("stock_db")[:12],
                "movimientos": MovimientoInventario.objects.select_related("producto", "bodega").order_by("-fecha")[:12],
            }
        )
        return context


class RecursosHumanosView(TemplateView):
    template_name = "modulos/rrhh.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        hoy = timezone.localdate()
        contratos = ContratoLaboral.objects.select_related("empleado", "cargo", "cargo__departamento").filter(fecha_inicio__lte=hoy).filter(Q(fecha_fin__isnull=True) | Q(fecha_fin__gte=hoy))
        context.update(
            {
                "empleados": Empleado.objects.filter(activo=True).prefetch_related("contratos__cargo__departamento").order_by("apellidos", "nombres"),
                "contratos": contratos,
                "nomina_mensual": contratos.aggregate(total=Coalesce(Sum("sueldo_base"), Value(Decimal("0")), output_field=DECIMAL_FIELD))["total"],
                "departamentos": contratos.values("cargo__departamento").distinct().count(),
            }
        )
        return context


class ProduccionView(TemplateView):
    template_name = "modulos/produccion.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "ordenes": OrdenProduccion.objects.select_related("receta", "receta__producto_terminado", "bodega").prefetch_related("consumos").order_by("-fecha_inicio")[:20],
                "planificadas": OrdenProduccion.objects.filter(estado=OrdenProduccion.Estado.PLANIFICADA).count(),
                "en_proceso": OrdenProduccion.objects.filter(estado=OrdenProduccion.Estado.PROCESO).count(),
                "completadas": OrdenProduccion.objects.filter(estado=OrdenProduccion.Estado.COMPLETADA).count(),
            }
        )
        return context


class FinanzasView(TemplateView):
    template_name = "modulos/finanzas.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        transacciones = TransaccionFinanciera.objects.select_related("categoria", "centro_costo")
        resumen = transacciones.aggregate(
            ingresos=Coalesce(Sum("monto", filter=Q(categoria__tipo="INGRESO")), Value(Decimal("0")), output_field=DECIMAL_FIELD),
            costos=Coalesce(Sum("monto", filter=Q(categoria__tipo="COSTO")), Value(Decimal("0")), output_field=DECIMAL_FIELD),
            gastos=Coalesce(Sum("monto", filter=Q(categoria__tipo="GASTO")), Value(Decimal("0")), output_field=DECIMAL_FIELD),
        )
        resumen["resultado"] = resumen["ingresos"] - resumen["costos"] - resumen["gastos"]
        context.update({"resumen": resumen, "transacciones": transacciones.order_by("-fecha")[:25]})
        return context


class ConfiguracionView(TemplateView):
    template_name = "configuracion.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["runtime"] = {
            "django": django.get_version(),
            "base_datos": settings.DATABASES["default"]["ENGINE"].split(".")[-1],
            "modelos": len(list(apps.get_app_config("productos").get_models())),
            "idioma": settings.LANGUAGE_CODE,
            "zona_horaria": settings.TIME_ZONE,
        }
        return context


def api_productos(request):
    data = [
        {
            "id": producto.pk,
            "sku": producto.sku,
            "nombre": producto.nombre,
            "categoria": producto.categoria.nombre,
            "marca": producto.marca.nombre if producto.marca else None,
            "unidad": producto.unidad.simbolo,
            "precio": str(producto.precio_db),
            "stock": str(producto.stock_db),
            "activo": producto.activo,
        }
        for producto in productos_con_indicadores().order_by("nombre")
    ]
    return JsonResponse({"total": len(data), "productos": data}, json_dumps_params={"ensure_ascii": False})


def api_producto_detalle(request, pk):
    producto = get_object_or_404(productos_con_indicadores(), pk=pk)
    return JsonResponse(
        {
            "id": producto.pk,
            "sku": producto.sku,
            "nombre": producto.nombre,
            "descripcion": producto.descripcion,
            "categoria": producto.categoria.nombre,
            "marca": producto.marca.nombre if producto.marca else None,
            "unidad": producto.unidad.simbolo,
            "precio": str(producto.precio_db),
            "stock": str(producto.stock_db),
            "punto_reorden": producto.punto_reorden,
            "activo": producto.activo,
            "actualizado": producto.actualizado.isoformat(),
        },
        json_dumps_params={"ensure_ascii": False},
    )
