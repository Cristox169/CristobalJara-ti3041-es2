from django.urls import path

from . import views

app_name = "productos"

urlpatterns = [
    path("", views.InicioView.as_view(), name="inicio"),
    path("productos/", views.ProductoListView.as_view(), name="lista"),
    path("productos/nuevo/", views.ProductoCreateView.as_view(), name="crear"),
    path("productos/<int:pk>/", views.ProductoDetailView.as_view(), name="detalle"),
    path("productos/<int:pk>/editar/", views.ProductoUpdateView.as_view(), name="editar"),
    path("productos/<int:pk>/eliminar/", views.ProductoDeleteView.as_view(), name="eliminar"),
    path("ventas/", views.VentasView.as_view(), name="ventas"),
    path("logistica/", views.LogisticaView.as_view(), name="logistica"),
    path("recursos-humanos/", views.RecursosHumanosView.as_view(), name="rrhh"),
    path("produccion/", views.ProduccionView.as_view(), name="produccion"),
    path("finanzas/", views.FinanzasView.as_view(), name="finanzas"),
    path("configuracion/", views.ConfiguracionView.as_view(), name="configuracion"),
    path("api/productos/", views.api_productos, name="api_productos"),
    path("api/productos/<int:pk>/", views.api_producto_detalle, name="api_detalle"),
]
